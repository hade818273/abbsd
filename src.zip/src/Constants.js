module.exports = {
  PREFIX: '!', 
  BALANCE_PRICE: 1000, ////سعر الكوينز
  BALANCE_LOG: '1117441860982554795',///روم تم شراء
  STOCK_CHANNEL: '1230505092667674716', ////روم كمية
  STOCK_MESSAGE: '1181084350931017758',///رسالة الكمية
  CLIENTS_ROLE: '1229696492281921546', //////رتبة شراء عادية
  DONE_CHANNEL: '1230505016574476428', //////روم تم شراء 
  SUPERCLIENTS_ROLE: '1224510931158175784', ////رتبة شراء فخمة
  MIN_MEMBERS: 25,
  RECIPIENT_ID: '948386383502901249',////البنك
  TRANSACTIONS_CHANNEL: '1230507849327841330', ////روم التحويل 
  CLIENT_ID: '1035715988638928988', ////id تبع بوت
  AUTH_URL: 'https://ad805f5b-0c21-4fa1-a4cd-72e27e82e039-00-1225r11cl4azg.spock.replit.dev/login',///هشرح  في الجزء الثاني
  BOT_URL: 'https://discord.com/oauth2/authorize?client_id=1035715988638928988&permissions=8&redirect_uri=https%3A%2F%2Fad805f5b-0c21-4fa1-a4cd-72e27e82e039-00-1225r11cl4azg.spock.replit.dev%2Flogin&scope=bot',
  PROBOT_IDS: ['282859044593598464', ''], 
  OWNERS: ['948386383502901249']////الاونر
};